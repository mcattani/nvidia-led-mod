# nvidia-led-mod
Pequeña aplicación para controlar el brillo del LED de algunas placas de video NVIDIA.

Estuve buscando en internet alguna aplicación para controlar el brillo del LED de la placa de video (sé que esto puede hacerse sin problemas en *Windows* desde la aplicación de *NVIDIA*) pero no encontré nada parecido.
Lo único que encontré fue referencias al comando:

> **nvidia-settings --assign GPULogoBrightness** 

A partir de esto me dispuse a crear una pequeña aplicación para encender y apagar la luz de la placa. 

Una vez hecho esto, también agregue unos pequeños efectos... *¿por qué no?*

> No tengo muy en claro que placas aeptan este comando, en mi caso tengo una **GeForce GTX 1050 Ti**.

Para más información visitá mi blog: https://thenerdyapprentice.blogspot.com/
